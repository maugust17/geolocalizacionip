﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace geolocalizacionip.Models
{
    public class IpResponse
    {
        public string ip {get; set;}
        public string country_code { get; set; }
    }
}
