﻿using StackExchange.Redis;
using geolocalizacionip.Rest;
using System.Text.Json;
using geolocalizacionip.Models;
using geolocalizacionip.Entidades;
using System.Linq;
using Geolocation;

namespace geolocalizacionip
{
    internal class Program
    {
        static TimeSpan tsDia = new TimeSpan(1, 0, 0, 0);
        static TimeSpan tsMes = new TimeSpan(30, 0, 0, 0);
        static async Task Main(string[] args)
        {

            string redisServer = Environment.GetEnvironmentVariable("VARIABLE_NET");

            string Brasil="104.41.63.254";
            //string España="83.44.196.93";
            string ip = Brasil;//args[0];
            DateTime horaActual = DateTime.Now;

           
            
            

            //Inicio la conexión a Redis
            //DB con la información completa por país(moneda, zon horaria, idiomas, etc)
            IDatabase paisDB = null;
            //DB con las cotizaciones por moneda
            IDatabase cotizacionDB = null;
            //DB con el Código ISO de país por IP
            IDatabase ipDB = null;
            try
            {
                paisDB = RedisDB.PaisDB;
                cotizacionDB = RedisDB.CotizacionDB;
                ipDB = RedisDB.IpDB;
            }
            catch (Exception e)
            {
                Console.WriteLine("Error al conectarse con el motor Redis. Revise los parámetros de conexión.");
                return; 
            }

            //Obtengo la cotización del Dolar. Si no existe s porque expiro el registro en Redis.
            string cotizacionDolar = await cotizacionDB.StringGetAsync("USD");
            if (cotizacionDolar == null)
            {
                CotizacionRest cotizacionRest = new CotizacionRest();
                CotizacionResponse cotizaciones = await cotizacionRest.Request();
                foreach (KeyValuePair<string, string> conversion in cotizaciones.rates)
                {
                    //Actualizo Redis con la nueva cotización. Los valores expiran en 1 día.
                    await cotizacionDB.StringSetAsync(conversion.Key, conversion.Value.Replace(".",","), tsDia);
                }

            }

            


            //Obtengo el codigo de país de la IP
            string codigoPaisIP = await ipDB.StringGetAsync(ip);
            if (codigoPaisIP == null)
            {
                var obtenerIP = new IpGeolocalizationRest();
                Task<string> consultaIP = obtenerIP.Request(ip);

                //Espero la respuesta de la API de Geolocalización
                try
                {
                    codigoPaisIP = await consultaIP;
                }
                catch (Exception e)
                {

                }
                //Actualizo Redis con la ip y el código de país
                await ipDB.StringSetAsync(ip, codigoPaisIP, tsDia);

            }
            else
            {
               
            
            }
           

            
            string jsonPais = await paisDB.StringGetAsync(codigoPaisIP);
            PaisResponse infoPais = null;
            if (jsonPais == null)
            {
                var obtenerPaises = new PaisesRest();
                Task<List<PaisResponse>> consultaPaises = obtenerPaises.Request();

                List<PaisResponse> listaPaises = await consultaPaises;
                foreach (PaisResponse pais in listaPaises)
                {
                    await paisDB.StringSetAsync(pais.cca2, JsonSerializer.Serialize(pais), tsMes);
                }
                jsonPais = await paisDB.StringGetAsync(codigoPaisIP);
                
            }
            //Convierto el Json obtenido en un objeto
            infoPais = JsonSerializer.Deserialize<PaisResponse>(jsonPais);

            InfoIP infoIP = new InfoIP();

            infoIP.IP = ip;
            infoIP.Idiomas = infoPais.languages.Select(x => new Idioma(x.Key, x.Value)).ToList<Idioma>();
            infoIP.Localizacion = new Localizacion(new Coordinate(infoPais.latlng[0], infoPais.latlng[1]));
            infoIP.HoraActual = horaActual;
            infoIP.Monedas = infoPais.currencies.Select(x => new Moneda(x.Value.name, x.Key, x.Value.symbol, 1.0/Convert.ToDouble(cotizacionDB.StringGet(x.Key)))).ToList<Moneda>();
            infoIP.Pais = new Pais(infoPais.translations["spa"].common, infoPais.name.common, infoPais.cca2, infoPais.cca3);
            infoIP.ZonasHorarias = infoPais.timezones;


            Console.WriteLine(infoIP.ToString());
        }
    }
}